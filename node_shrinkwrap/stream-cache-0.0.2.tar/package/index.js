module.exports = require('./lib/StreamCache');
