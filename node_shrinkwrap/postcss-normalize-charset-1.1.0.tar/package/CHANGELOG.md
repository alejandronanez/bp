# 1.1.0

* Added `add` option (thanks to @ben-eb)

# 1.0.0

* Initial release.
