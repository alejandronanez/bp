# 1.0.3

* Resolves an issue where `0` was being incorrectly stripped from the final
  colour stop value.

# 1.0.2

* Resolves an issue where the module would incorrectly parse floating
  point numbers.

# 1.0.1

* Reduce function iterations (thanks to @TrySound).

# 1.0.0

* Initial release.
