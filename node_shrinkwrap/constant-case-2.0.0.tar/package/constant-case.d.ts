declare function constantCase (value: string, locale?: string): string;

export = constantCase;
