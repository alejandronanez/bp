# Change Log

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

<a name="1.1.0"></a>
# [1.1.0](https://github.com/bcoe/test-exclude/compare/v1.0.0...v1.1.0) (2016-06-08)


### Features

* set configFound if we find a configuration key in package.json ([#2](https://github.com/bcoe/test-exclude/issues/2)) ([64da7b9](https://github.com/bcoe/test-exclude/commit/64da7b9))



<a name="1.0.0"></a>
# 1.0.0 (2016-06-06)


### Features

* initial commit, pulled over some of the functionality from nyc ([3f1fce3](https://github.com/bcoe/test-exclude/commit/3f1fce3))
* you can now load include/exclude logic from a package.json stanza ([#1](https://github.com/bcoe/test-exclude/issues/1)) ([29b543d](https://github.com/bcoe/test-exclude/commit/29b543d))
