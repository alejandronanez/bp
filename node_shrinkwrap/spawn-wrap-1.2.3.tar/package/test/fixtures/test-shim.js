console.log('before in shim')
require('../..').runMain()
console.log('after in shim')
