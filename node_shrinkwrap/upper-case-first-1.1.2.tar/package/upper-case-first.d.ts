declare function upperCaseFirst (value: string, locale?: string): string;

export = upperCaseFirst;
