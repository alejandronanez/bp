// just be silly with calling these functions a bunch
// mostly just to get coverage of the guard branches
var onSignalExit = require('../../')
onSignalExit.load()
onSignalExit.load()
onSignalExit.unload()
onSignalExit.unload()
