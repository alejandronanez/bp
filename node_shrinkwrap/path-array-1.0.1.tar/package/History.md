
1.0.1 / 2016-01-14
==================

  * add MIT LICENSE file
  * update "array-index" to v1.0.0 with new API
  * travis: test more node versions and fix v0.8
  * travis: use quotes around node versions

1.0.0 / 2014-11-11
==================

  * index: add support for a configrable `property` name to use
  * README: fix Travis badge

0.0.2 / 2013-12-22
==================

  * README++
  * test: add unshift() test
  * test: add more tests
  * index: ensure that the indexed getters/setters are set up in the constructor
  * add .travis.yml file
  * add initial tests

0.0.1 / 2013-12-21
==================

  * add README.md
  * initial commit
