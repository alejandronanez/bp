declare function headerCase (value: string, locale?: string): string;

export = headerCase;
