The package exports an array of strings.
