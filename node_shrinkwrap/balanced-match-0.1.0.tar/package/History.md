
0.1.0 / 2014-04-24
==================

 * docs
 * refactor
 * a and b can be longer than 1 char
 * fix match when b comes before a
 * add make test

