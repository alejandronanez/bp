declare function snakeCase (value: string, locale?: string): string;

export = snakeCase;
