declare function isLowerCase (value: string, locale?: string): boolean;

export = isLowerCase;
