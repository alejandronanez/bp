2.0.8 / 2016-05-12
==================

  * deps: mime-db@'>= 1.23.0 < 2'

2.0.7 / 2016-01-18
==================

  * deps: mime-db@'>= 1.21.0 < 2'

2.0.6 / 2015-09-29
==================

  * deps: mime-db@'>= 1.19.0 < 2'

2.0.5 / 2015-07-30
==================

  * deps: mime-db@'>= 1.16.0 < 2'

2.0.4 / 2015-07-01
==================

  * deps: mime-db@'>= 1.14.0 < 2'
  * perf: enable strict mode

2.0.3 / 2015-06-08
==================

  * Fix regex fallback to work if type exists, but is undefined
  * perf: hoist regex declaration
  * perf: use regex to extract mime
  * deps: mime-db@'>= 1.13.0 < 2'

2.0.2 / 2015-01-31
==================

  * deps: mime-db@'>= 1.1.2 < 2'

2.0.1 / 2014-09-28
==================

  * deps: mime-db@1.x
    - Add new mime types
    - Add additional compressible
    - Update charsets


2.0.0 / 2014-09-02
==================

  * use mime-db
  * remove .get()
  * specifications are now private
  * regex is now private
  * stricter regex
