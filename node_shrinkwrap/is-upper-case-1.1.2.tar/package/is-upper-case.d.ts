declare function isUpperCase (value: string, locale?: string): string;

export = isUpperCase;
